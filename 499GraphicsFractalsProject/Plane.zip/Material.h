#pragma once
#include <glm/ext/vector_float3.hpp>
#include <GL/glew.h>

struct Material
{
	glm::vec3 ambient;
	glm::vec3 diffuse;
	glm::vec3 specular;
	GLfloat shininess;
	GLuint specularMap;
	GLuint diffuseMap;
};