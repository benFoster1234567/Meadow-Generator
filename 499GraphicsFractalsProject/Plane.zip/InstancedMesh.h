#pragma once
#include "GL/glew.h"
#include "Mesh.h"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/quaternion.hpp>
#include "Shader.h"
#include "Material.h"
#include <algorithm>


struct InstanceData
{
	glm::vec3 position{};
	glm::vec3 rotationEuler{};
	glm::vec3 scale{};
	glm::vec4 color{};
};

class InstancedMesh
{
public:

	InstancedMesh() = default;

	explicit InstancedMesh(const Mesh& mesh, Shader& shader)
		: m_shader(shader), mesh(mesh) {
	}

	~InstancedMesh() { release(); }

	InstancedMesh(const InstancedMesh&) = delete;
	InstancedMesh& operator=(const InstancedMesh&) = delete;

	InstancedMesh(InstancedMesh&& other) noexcept
		: m_shader(other.m_shader),
		m_vao(std::exchange(other.m_vao, 0)),
		m_vbo(std::exchange(other.m_vbo, 0)),
		m_ebo(std::exchange(other.m_ebo, 0)),
		m_ibo(std::exchange(other.m_ibo, 0)),
		mesh(std::move(other.mesh)),
		m_instanceData(std::move(other.m_instanceData)) {
	}

	InstancedMesh& operator=(InstancedMesh&& other) noexcept
	{
		if (this != &other)
		{
			release();
			m_vao = std::exchange(other.m_vao, 0);
			m_vbo = std::exchange(other.m_vbo, 0);
			m_ebo = std::exchange(other.m_ebo, 0);
			m_ibo = std::exchange(other.m_ibo, 0);
			mesh = std::move(other.mesh);
			m_instanceData = std::move(other.m_instanceData);
		}
		return *this;
	}

	void addInstance(const InstanceData& data)
	{
		m_instanceData.push_back(packInstance(data));
	}

	void addInstance(const glm::mat4& data)
	{
		m_instanceData.push_back(data);
	}

	void initialize()
	{
		glGenVertexArrays(1, &m_vao);
		glBindVertexArray(m_vao);
		glGenBuffers(1, &m_vbo);
		glGenBuffers(1, &m_ebo);
		glGenBuffers(1, &m_ibo);

		glBindBuffer(GL_ARRAY_BUFFER, m_vbo);
		glBufferData(GL_ARRAY_BUFFER, mesh.m_data.size() * sizeof(VertexData), mesh.m_data.data(), GL_STATIC_DRAW);

		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(VertexData), (void*)offsetof(VertexData, point));
		glEnableVertexAttribArray(0);

		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(VertexData), (void*)offsetof(VertexData, normal));
		glEnableVertexAttribArray(1);

		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(VertexData), (void*)offsetof(VertexData, texCoord));
		glEnableVertexAttribArray(2);

		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_ebo);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, mesh.m_indices.size() * sizeof(unsigned int), mesh.m_indices.data(), GL_STATIC_DRAW);

		glBindBuffer(GL_ARRAY_BUFFER, m_ibo);
		glBufferData(GL_ARRAY_BUFFER, m_instanceData.size() * sizeof(glm::mat4), m_instanceData.data(), GL_DYNAMIC_DRAW);

		for (int i = 0; i < 4; ++i) // puts the whole matrix into the shaders as 4 vec4s
		{
			GLuint attribIndex = 3 + i;
			GLuint stride = sizeof(glm::mat4);
			GLuint size = 4;
			glVertexAttribPointer(attribIndex, size, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(glm::vec4) * i));
			glEnableVertexAttribArray(attribIndex);
			glVertexAttribDivisor(attribIndex, 1);
		}

		m_initialized = true;
		m_dirty = false;
		glBindVertexArray(0);
	}

	void draw()
	{
		glBindVertexArray(m_vao);
		glDrawElementsInstanced(GL_TRIANGLES, mesh.m_indices.size(), GL_UNSIGNED_INT, (void*)0, m_instanceData.size());
	}

	std::vector<VertexData> getMeshData()
	{
		return mesh.m_data;
	}

	std::vector<glm::mat4> getInstanceData()
	{
		return m_instanceData;
	}

	void changeMeshData(std::vector<VertexData> meshData)
	{
		glBindVertexArray(m_vao);
		glBindBuffer(GL_ARRAY_BUFFER, m_vbo);
		mesh.m_data.assign(meshData.begin(), meshData.end());
		glBufferSubData(GL_ARRAY_BUFFER, 0, mesh.m_data.size() * sizeof(VertexData), mesh.m_data.data());
		//glBindVertexArray(0);
	}

	void setInstanceData(std::vector<glm::mat4> instanceData)
	{
		m_instanceData = std::move(instanceData);
		//std::cout << "instance data size: " << m_instanceData.size() << "\n";
	}

	void changeInstanceData(std::vector<glm::mat4> instanceData)
	{
		m_instanceData.assign(instanceData.begin(), instanceData.end());
		//std::cout << "instance data size: " << m_instanceData.size() << "\n";
	}

	Shader& m_shader;
private:

	std::vector<glm::mat4> m_instanceData{};
	
	void release()
	{
		if (m_vbo) glDeleteBuffers(1, &m_vbo);
		if (m_ebo) glDeleteBuffers(1, &m_ebo);
		if (m_ibo) glDeleteBuffers(1, &m_ibo);
		if (m_vao) glDeleteVertexArrays(1, &m_vao);
		m_vao = m_vbo = m_ebo = m_ibo = 0;
	}

	glm::mat4 packInstance(const InstanceData& instance)
	{
		glm::mat4 pos = glm::translate(glm::mat4(1), instance.position);
		glm::mat4 rot = glm::toMat4(glm::quat(instance.rotationEuler));
		glm::mat4 scale = glm::scale(glm::mat4(1), instance.scale);

		glm::mat4 transform = pos * rot * scale;

		transform[0].w = instance.color.r;
		transform[1].w = instance.color.g;
		transform[2].w = instance.color.b;
		transform[3].w = instance.color.a;

		return transform;
	}

	//GLuint shaderProgram{};
	GLuint m_vao{};
	GLuint m_vbo{};
	GLuint m_ebo{};
	GLuint m_ibo{};

	bool m_dirty = false;
	bool m_initialized = false;
	Mesh mesh{};

};