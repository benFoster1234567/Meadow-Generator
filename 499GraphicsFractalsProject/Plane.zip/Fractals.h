#pragma once
#include <glm/ext/matrix_float4x4.hpp>
#include <glm/ext/scalar_constants.hpp>
#include "Random.h"
#include <glm/trigonometric.hpp>
#include <glm/ext/matrix_transform.hpp>
#include <iostream>


class Fractals
{
public:
	static std::vector<glm::mat4> makeFractal(unsigned int density, unsigned int levels, float radius, float randomize = 0.3f, float rotFactor = 1.0f)
	{
		std::vector<glm::mat4> matrices{};

		glm::mat4 t{ 1.f };
		size_t count = 0;
		struct StackFrame
		{
			glm::mat4 t;
			unsigned int levels;
			float radius;
		};

		std::vector<StackFrame> stack{};
		stack.reserve(10000000);
		stack.push_back(StackFrame{ .t = t,.levels = levels, .radius = radius });

		float interval = 2 * glm::pi<float>() / density;
		float r = 2 * glm::pi<float>() / Random::nextFloat(0, randomize);

		std::vector<glm::vec2> angledUnitVectors{};
		angledUnitVectors.reserve(density);

		for (int i{ 0 }; i < density; ++i)
		{
			float theta = i * interval + r;
			angledUnitVectors.emplace_back(glm::cos(theta), glm::sin(theta));
		}

		while (!stack.empty())
		{
			StackFrame stackFrame = stack.back();
			stack.pop_back();

			if (stackFrame.levels > 0)
			{
				//addInstanceTransform(stackFrame.t);
				matrices.push_back(stackFrame.t);
				count++;
				for (int i = 0; i < density; ++i)
				{
					float theta = i * interval + r;

					float x = stackFrame.radius * angledUnitVectors[i].x + Random::nextFloat(-randomize, randomize); //replace with something way faster
					float z = stackFrame.radius * angledUnitVectors[i].y + Random::nextFloat(-randomize, randomize);

					glm::vec3 p = { x, 0, z };

					float phi = rotFactor * theta;

					glm::mat4 transform = translate(glm::mat4{ 1.f }, glm::vec3(x, 0, z)) * glm::rotate(glm::mat4(1), phi, glm::vec3(0, 1, 0));

					stack.emplace_back(StackFrame{ .t = transform * stackFrame.t, .levels = stackFrame.levels - 1, .radius = stackFrame.radius * 0.333f });
				}
			}
		}

		return matrices;

	}
};