#pragma once
#include "Shader.h"
#include "Fractals.h"
#include "InstancedMesh.h"
#include "OpenGL.h"
#include "Light.h"
#include "RenderUniforms.h"

class Meadow
{
public:


	struct Settings
	{
		Mesh& grassMesh;

		Mesh& flowerPetalsMesh;
		Mesh& flowerStemMesh;
		Mesh& flowerLeaf1Mesh;
		Mesh& flowerLeaf2Mesh;
		Mesh& flowerLeaf3Mesh;

		Material flowerPetalsMaterial;
		Material flowerStemMaterial;
		Material flowerLeafMaterial;

		Shader& shader;

		glm::mat4 baseTransform;
	};

	Meadow(Settings s)
		: grass{ s.grassMesh, s.shader }
		, flowerPetals{ s.flowerPetalsMesh, s.shader }
		, flowerStem{ s.flowerStemMesh, s.shader }
		, flowerLeaf1{ s.flowerLeaf1Mesh, s.shader }
		, flowerLeaf2{ s.flowerLeaf2Mesh, s.shader }
		, flowerLeaf3{ s.flowerLeaf3Mesh, s.shader }
		, m_settings{s}
	{
		grassBaseTransform = glm::scale(glm::mat4(1), { 0.1f,0.1f,0.1f });
	}

	void draw(const RenderIn& u)
	{
		auto drawElem = [this, u](InstancedMesh& m, Material& mat)
			{
				m.m_shader.setMat4("projection", u.proj);
				m.m_shader.setMat4("view", u.view);
				m.m_shader.setMat4("model", grassBaseTransform);
				m.m_shader.setVec3("viewPosition", u.viewPos);
				m.m_shader.setMat3("texture", u.texture);
				m.m_shader.setLight("light", u.light);
				m.m_shader.setMaterial(mat);
				m.draw();
			};

		drawElem(flowerPetals, m_settings.flowerPetalsMaterial);
		drawElem(flowerStem, m_settings.flowerStemMaterial);
		drawElem(flowerLeaf1, m_settings.flowerLeafMaterial);
		drawElem(flowerLeaf2, m_settings.flowerLeafMaterial);
		drawElem(flowerLeaf3, m_settings.flowerLeafMaterial);
	}

	void arrangeGrass(unsigned int density, unsigned int levels, float radius, float randomize = 0.3f, float rotFactor = 1.0f)
	{
		auto fVec = Fractals::makeFractal(density, levels, radius, randomize, rotFactor);
		//std::cout << fVec.size() << "grasses arranged\n";
		grass.setInstanceData(fVec);
	}

	void arrangeFlowers(unsigned int density, unsigned int levels, float radius, float randomize = 0.3f, float rotFactor = 1.0f)
	{
		auto fVec = Fractals::makeFractal(density, levels, radius, randomize, rotFactor);
		//std::cout << fVec.size() << " flowers arranged\n";
		flowerPetals.setInstanceData(fVec);
		flowerStem.setInstanceData(fVec);
		flowerLeaf1.setInstanceData(fVec);
		flowerLeaf2.setInstanceData(fVec);
		flowerLeaf3.setInstanceData(fVec);
	}

	void init()
	{
		grass.initialize();
		flowerPetals.initialize();
		flowerStem.initialize();
		flowerLeaf1.initialize();
		flowerLeaf2.initialize();
		flowerLeaf3.initialize();
	}

private:
	glm::mat4 grassBaseTransform{1.0f};

	InstancedMesh grass;
	InstancedMesh flowerPetals;
	InstancedMesh flowerStem;
	InstancedMesh flowerLeaf1;
	InstancedMesh flowerLeaf2;
	InstancedMesh flowerLeaf3;

	Settings m_settings;
};