#pragma once
#include <glm/ext/matrix_float4x4.hpp>
#include "Light.h"

struct RenderIn
{
	glm::mat4 proj;
	glm::mat4 view;
	glm::vec3 viewPos;
	glm::mat3 texture;
	Light light;
};